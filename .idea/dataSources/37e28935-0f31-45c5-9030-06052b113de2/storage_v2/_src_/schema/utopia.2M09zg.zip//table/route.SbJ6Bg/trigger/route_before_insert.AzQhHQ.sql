create definer = root@localhost trigger route_BEFORE_INSERT
	before insert
	on route
	for each row
BEGIN
	IF (NEW.origin_id = NEW.destination_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'origin cannot be same as destination';
	END IF;
END;

